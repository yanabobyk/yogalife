import browserSync from "browser-sync";

export const plugins = {
    browserSync: browserSync,
}


